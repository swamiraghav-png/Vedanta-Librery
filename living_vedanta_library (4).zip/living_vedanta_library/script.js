async function loadPosts(){
  const res = await fetch('posts.json');
  const posts = await res.json();
  const list = document.getElementById('postList');
  const input = document.getElementById('searchBox');
  function render(q=''){
    const query=q.toLowerCase().trim();
    const shown=posts.filter(p=>[p.title,p.series,p.part,p.keywords,p.verse,p.summary].join(' ').toLowerCase().includes(query));
    list.innerHTML = shown.map(p=>`<article class="post-item"><div><span class="tag">${p.series}</span> <span class="tag">${p.part}</span></div><h3><a href="${p.url}">${p.title}</a></h3><p class="sanskrit">${p.verse.replaceAll('\n','<br>')}</p><p>${p.summary}</p></article>`).join('') || '<p>No matching post yet. Add more posts to the archive.</p>';
  }
  input.addEventListener('input',e=>render(e.target.value));
  render();
}
loadPosts();
